
   // Feedback form submission handler
   document.getElementById('feedbackForm').addEventListener('submit', function (e) {
    e.preventDefault();
    alert('Thank you for your feedback!');
    this.reset();
});


gsap.from("nav div a,.signin,.navbar-toggler",{
     duration:1.5,
     y:-100,   
})
gsap.from(".hero-content h1",{
     scale:0,
     duration:1.5,
     x:-50,
})
gsap.from("#gallery .filter-btn",{
 duration:1.5,
 y:-50,
 opacity:0,
 stagger:0.5,
})



