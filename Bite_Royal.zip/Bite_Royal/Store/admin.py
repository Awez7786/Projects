from django.contrib import admin
from Store.models import Contact,Product,Orders

admin.site.register(Contact)
admin.site.register(Product)
admin.site.register(Orders)
# Register your models here.
